
; /* Start:"a:4:{s:4:"full";s:88:"/bitrix/components/bitrix/menu/templates/vertical_multilevel/script.min.js?1721110527409";s:6:"source";s:70:"/bitrix/components/bitrix/menu/templates/vertical_multilevel/script.js";s:3:"min";s:74:"/bitrix/components/bitrix/menu/templates/vertical_multilevel/script.min.js";s:3:"map";s:74:"/bitrix/components/bitrix/menu/templates/vertical_multilevel/script.map.js";}"*/
var jsvhover=function(){var e=document.getElementById("vertical-multilevel-menu");if(!e)return;var t=e.getElementsByTagName("li");for(var n=0;n<t.length;n++){t[n].onmouseover=function(){this.className+=" jsvhover"};t[n].onmouseout=function(){this.className=this.className.replace(new RegExp(" jsvhover\\b"),"")}}};if(window.attachEvent)window.attachEvent("onload",jsvhover);
/* End */
;; /* /bitrix/components/bitrix/menu/templates/vertical_multilevel/script.min.js?1721110527409*/

//# sourceMappingURL=template_05c12f2d8c09532fc30d062ab5321e31.map.js