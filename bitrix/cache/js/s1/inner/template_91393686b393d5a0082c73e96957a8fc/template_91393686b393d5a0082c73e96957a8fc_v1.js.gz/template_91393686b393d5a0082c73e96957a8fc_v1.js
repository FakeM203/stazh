
; /* Start:"a:4:{s:4:"full";s:87:"/bitrix/templates/.default/components/bitrix/menu/left-menu/script.min.js?1721386817409";s:6:"source";s:69:"/bitrix/templates/.default/components/bitrix/menu/left-menu/script.js";s:3:"min";s:73:"/bitrix/templates/.default/components/bitrix/menu/left-menu/script.min.js";s:3:"map";s:73:"/bitrix/templates/.default/components/bitrix/menu/left-menu/script.map.js";}"*/
var jsvhover=function(){var e=document.getElementById("vertical-multilevel-menu");if(!e)return;var t=e.getElementsByTagName("li");for(var n=0;n<t.length;n++){t[n].onmouseover=function(){this.className+=" jsvhover"};t[n].onmouseout=function(){this.className=this.className.replace(new RegExp(" jsvhover\\b"),"")}}};if(window.attachEvent)window.attachEvent("onload",jsvhover);
/* End */
;; /* /bitrix/templates/.default/components/bitrix/menu/left-menu/script.min.js?1721386817409*/

//# sourceMappingURL=template_91393686b393d5a0082c73e96957a8fc.map.js