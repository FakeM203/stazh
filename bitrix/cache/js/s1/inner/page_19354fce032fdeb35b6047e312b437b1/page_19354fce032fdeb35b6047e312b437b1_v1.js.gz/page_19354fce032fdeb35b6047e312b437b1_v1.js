
; /* Start:"a:4:{s:4:"full";s:90:"/bitrix/components/bitrix/menu/templates/horizontal_multilevel/script.min.js?1721110527407";s:6:"source";s:72:"/bitrix/components/bitrix/menu/templates/horizontal_multilevel/script.js";s:3:"min";s:76:"/bitrix/components/bitrix/menu/templates/horizontal_multilevel/script.min.js";s:3:"map";s:76:"/bitrix/components/bitrix/menu/templates/horizontal_multilevel/script.map.js";}"*/
var jshover=function(){var e=document.getElementById("horizontal-multilevel-menu");if(!e)return;var t=e.getElementsByTagName("li");for(var n=0;n<t.length;n++){t[n].onmouseover=function(){this.className+=" jshover"};t[n].onmouseout=function(){this.className=this.className.replace(new RegExp(" jshover\\b"),"")}}};if(window.attachEvent)window.attachEvent("onload",jshover);
/* End */
;; /* /bitrix/components/bitrix/menu/templates/horizontal_multilevel/script.min.js?1721110527407*/

//# sourceMappingURL=page_19354fce032fdeb35b6047e312b437b1.map.js