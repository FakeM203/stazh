
; /* Start:"a:4:{s:4:"full";s:87:"/bitrix/templates/.default/components/bitrix/menu/top_multi/script.min.js?1721371338407";s:6:"source";s:69:"/bitrix/templates/.default/components/bitrix/menu/top_multi/script.js";s:3:"min";s:73:"/bitrix/templates/.default/components/bitrix/menu/top_multi/script.min.js";s:3:"map";s:73:"/bitrix/templates/.default/components/bitrix/menu/top_multi/script.map.js";}"*/
var jshover=function(){var e=document.getElementById("horizontal-multilevel-menu");if(!e)return;var t=e.getElementsByTagName("li");for(var n=0;n<t.length;n++){t[n].onmouseover=function(){this.className+=" jshover"};t[n].onmouseout=function(){this.className=this.className.replace(new RegExp(" jshover\\b"),"")}}};if(window.attachEvent)window.attachEvent("onload",jshover);
/* End */
;; /* /bitrix/templates/.default/components/bitrix/menu/top_multi/script.min.js?1721371338407*/

//# sourceMappingURL=page_7d6962a17e15b856d0215b36aa07b0db.map.js