
; /* Start:"a:4:{s:4:"full";s:84:"/bitrix/templates/inner/components/bitrix/menu/top_multi/script.min.js?1721371863407";s:6:"source";s:66:"/bitrix/templates/inner/components/bitrix/menu/top_multi/script.js";s:3:"min";s:70:"/bitrix/templates/inner/components/bitrix/menu/top_multi/script.min.js";s:3:"map";s:70:"/bitrix/templates/inner/components/bitrix/menu/top_multi/script.map.js";}"*/
var jshover=function(){var e=document.getElementById("horizontal-multilevel-menu");if(!e)return;var t=e.getElementsByTagName("li");for(var n=0;n<t.length;n++){t[n].onmouseover=function(){this.className+=" jshover"};t[n].onmouseout=function(){this.className=this.className.replace(new RegExp(" jshover\\b"),"")}}};if(window.attachEvent)window.attachEvent("onload",jshover);
/* End */
;; /* /bitrix/templates/inner/components/bitrix/menu/top_multi/script.min.js?1721371863407*/

//# sourceMappingURL=page_68f019a3bd5ed0363b15172b461162ab.map.js